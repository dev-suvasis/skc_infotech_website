import Link from 'next/link';

const Topbar = () => {
  return (
    <div className="bg-[#0F172A] text-white font-display text-xs font-medium tracking-wide hidden md:flex z-50  top-0 w-full h-[40px] opacity-90 hover:opacity-100 transition-opacity">
      <div className="flex justify-end items-center w-full px-8 max-w-[1280px] mx-auto gap-6">
        <nav className="flex items-center gap-6">
          <Link className="text-slate-300 hover:text-white transition-colors" href="/contact">Support</Link>
          <Link className="text-slate-300 hover:text-white transition-colors" href="/about">Docs</Link>
          <Link className="text-slate-300 hover:text-white transition-colors" href="/contact">Login</Link>
        </nav>
        <button className="text-slate-300 hover:text-white transition-colors flex items-center justify-center">
          <span className="material-symbols-outlined text-[16px]">language</span>
        </button>
      </div>
    </div>
  );
};

export default Topbar;