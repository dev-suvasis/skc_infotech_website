import Link from 'next/link';

const Footer = () => {
  return (
    <footer className="bg-[#0F172A] text-white font-display text-sm leading-relaxed block w-full pt-20 pb-10 border-t border-slate-800 transition-opacity mt-24">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 max-w-[1280px] mx-auto px-8">
        <div className="col-span-1 md:col-span-2">
          <div className="text-2xl font-black text-white mb-4">SKC Infotech</div>
          <p className="text-slate-400 mb-8 max-w-sm">
            Building smart software for business growth with secure, scalable, and innovative IT solutions.
          </p>
          
          {/* Newsletter Signup */}
          <div className="relative max-w-sm">
            <input 
              className="w-full bg-white/5 border border-white/10 rounded-lg py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:border-secondary focus:bg-white/10 transition-colors" 
              placeholder="Subscribe to insights" 
              type="email"
            />
            <button className="absolute right-2 top-2 bottom-2 bg-secondary text-white rounded px-4 text-xs font-bold hover:bg-secondary/80 transition-colors">
              Join
            </button>
          </div>
        </div>

        <div className="col-span-1">
          <h4 className="font-display text-white mb-6 uppercase tracking-wider text-xs font-bold">Company</h4>
          <ul className="flex flex-col gap-4">
            <li><Link className="text-slate-400 hover:text-white transition-colors" href="/about">About Us</Link></li>
            <li><Link className="text-slate-400 hover:text-white transition-colors" href="/career">Careers</Link></li>
            <li><Link className="text-slate-400 hover:text-white transition-colors" href="/apps">Services</Link></li>
          </ul>
        </div>

        <div className="col-span-1">
          <h4 className="font-display text-white mb-6 uppercase tracking-wider text-xs font-bold">Legal</h4>
          <ul className="flex flex-col gap-4">
            <li><Link className="text-slate-400 hover:text-white transition-colors" href="/contact">Privacy Policy</Link></li>
            <li><Link className="text-slate-400 hover:text-white transition-colors" href="/contact">Terms of Service</Link></li>
          </ul>
        </div>
      </div>

      <div className="max-w-[1280px] mx-auto px-8 mt-16 pt-8 border-t border-slate-800/50 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-slate-500 text-xs">© 2024 SKC Infotech. All rights reserved.</p>
        <div className="flex gap-4">
          <a className="text-slate-500 hover:text-white transition-colors" href="#">
            <span className="material-symbols-outlined text-[20px]">share</span>
          </a>
          <a className="text-slate-500 hover:text-white transition-colors" href="#">
            <span className="material-symbols-outlined text-[20px]">mail</span>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;