'use client';

import React from 'react';
import Link from 'next/link';

const ContactPage = () => {
  return (
    <div className="flex flex-col w-full animate-fade-in pb-20">
      {/* Hero Section */}
      <section className="bg-surface pt-32 pb-24 px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(75,65,225,0.05)_0%,transparent_70%)] -z-10"></div>
        <div className="max-w-[1220px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-slide-up">
            <h1 className="text-[64px] font-bold text-on-background leading-[1.1] tracking-[-0.02em]">
              Let's build <br/>
              <span className="text-secondary">Together.</span>
            </h1>
            <p className="text-[18px] text-on-surface-variant max-w-lg leading-[1.6]">
              Have a project in mind? We're here to help you scale your business with enterprise-grade solutions. Reach out to us today.
            </p>
          </div>
          <div className="relative h-[400px] w-full flex justify-center items-center animate-fade-in">
            <div className="w-full h-full bg-surface-container-low rounded-3xl border border-outline-variant/30 relative overflow-hidden group shadow-modern">
               <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(75,65,225,0.1),transparent)]"></div>
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-4 text-secondary">
                  <span className="material-symbols-outlined text-[64px]">explore</span>
                  <span className="text-[14px] font-bold tracking-widest uppercase">Global Operations</span>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Info & Form */}
      <section className="py-24 px-8 bg-surface border-y border-outline-variant/20">
        <div className="max-w-[1220px] mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Left: Contact Info */}
          <div className="lg:col-span-1 space-y-12">
            <div>
              <h2 className="text-[32px] font-bold text-on-background mb-6 tracking-tight">Our Offices</h2>
              <div className="space-y-8">
                <div className="group">
                  <h4 className="text-[18px] font-bold text-on-background mb-2">India (HQ)</h4>
                  <p className="text-on-surface-variant text-[15px] leading-relaxed">
                    123 Business Hub, Salt Lake City,<br/>
                    Kolkata, West Bengal 700091
                  </p>
                  <p className="text-secondary text-[14px] font-medium mt-2">info@skcinfotech.in</p>
                </div>
                <div className="group">
                  <h4 className="text-[18px] font-bold text-on-background mb-2">Support Center</h4>
                  <p className="text-on-surface-variant text-[15px] leading-relaxed">
                    Dedicated 24/7 technical assistance for all our enterprise clients worldwide.
                  </p>
                  <p className="text-secondary text-[14px] font-medium mt-2">support@skcinfotech.in</p>
                </div>
              </div>
            </div>

            <div className="bg-surface-container-low p-8 rounded-2xl border border-outline-variant/30">
              <h4 className="text-[18px] font-bold text-on-background mb-4">Quick Links</h4>
              <nav className="flex flex-col gap-4">
                <Link className="text-on-surface-variant hover:text-secondary transition-colors text-[14px]" href="/about">About SKC Infotech</Link>
                <Link className="text-on-surface-variant hover:text-secondary transition-colors text-[14px]" href="/career">Careers</Link>
                <Link className="text-on-surface-variant hover:text-secondary transition-colors text-[14px]" href="/apps">Our Services</Link>
              </nav>
            </div>
          </div>

          {/* Right: Form */}
          <div className="lg:col-span-2 bg-white p-10 rounded-2xl shadow-modern border border-outline-variant/30">
            <h2 className="text-[32px] font-bold text-on-background mb-8 tracking-tight">Send an Inquiry</h2>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[13px] font-bold text-on-surface uppercase tracking-wider">Full Name</label>
                <input className="w-full bg-surface-container-low border border-outline-variant/30 rounded-lg p-3 text-[15px] focus:outline-none focus:border-secondary transition-colors" placeholder="John Doe" type="text" />
              </div>
              <div className="space-y-2">
                <label className="text-[13px] font-bold text-on-surface uppercase tracking-wider">Email Address</label>
                <input className="w-full bg-surface-container-low border border-outline-variant/30 rounded-lg p-3 text-[15px] focus:outline-none focus:border-secondary transition-colors" placeholder="john@example.com" type="email" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-[13px] font-bold text-on-surface uppercase tracking-wider">Subject</label>
                <select className="w-full bg-surface-container-low border border-outline-variant/30 rounded-lg p-3 text-[15px] focus:outline-none focus:border-secondary transition-colors">
                  <option>Software Solution Inquiry</option>
                  <option>Web Development Inquiry</option>
                  <option>App Development Inquiry</option>
                  <option>Career Opportunity</option>
                  <option>Others</option>
                </select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-[13px] font-bold text-on-surface uppercase tracking-wider">Message</label>
                <textarea className="w-full bg-surface-container-low border border-outline-variant/30 rounded-lg p-3 text-[15px] h-32 focus:outline-none focus:border-secondary transition-colors" placeholder="How can we help you?"></textarea>
              </div>
              <div className="md:col-span-2">
                <button className="bg-secondary text-white px-10 py-4 rounded-xl font-bold hover:shadow-premium transition-all active:scale-95 w-full md:w-fit">
                  Send Message
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-24 px-8">
        <div className="max-w-[1220px] mx-auto rounded-3xl overflow-hidden h-[400px] relative shadow-modern border border-outline-variant/30">
          <div className="absolute inset-0 bg-slate-100 flex items-center justify-center grayscale">
            <span className="material-symbols-outlined text-slate-300 text-[120px]">map</span>
          </div>
          <div className="absolute top-8 left-8 bg-white p-6 rounded-xl shadow-lg border border-outline-variant/20 max-w-xs animate-slide-up">
            <h4 className="text-[16px] font-bold text-on-background mb-2">Main Headquarters</h4>
            <p className="text-[13px] text-on-surface-variant mb-4">Visit us for a coffee and discuss your next big project.</p>
            <Link className="inline-flex items-center text-secondary text-[14px] font-bold hover:gap-2 transition-all" href="/contact">
              Get Directions <span className="material-symbols-outlined text-[16px] ml-1">navigation</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;