import React from 'react';

const WebsitePage = () => {
  return (
    <div className="flex flex-col w-full animate-fade-in">
      {/* Hero Section */}
      <section className="pt-12 pb-24 px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(75,65,225,0.05)_0%,transparent_70%)] -z-10 pointer-events-none"></div>
        <div className="max-w-[1220px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-8 animate-slide-up">
            <h1 className="text-[64px] font-bold text-on-background leading-[1.1] tracking-[-0.02em]">
              Make your Business Grow with us.
            </h1>
            <p className="text-[18px] text-on-surface-variant max-w-2xl leading-[1.6]">
              We provide custom content management systems (CMS) using WordPress, Laravel, and other frameworks, and build modern, fast, responsive websites using Angular, React, PHP, etc.
            </p>
            <div className="flex gap-4 pt-4">
              <button className="bg-secondary text-white px-8 py-3 rounded-lg text-[14px] font-bold hover:shadow-[0_4px_20px_rgba(75,65,225,0.4)] transition-all active:scale-95">
                Explore Capabilities
              </button>
              <button className="bg-transparent text-secondary border border-outline px-8 py-3 rounded-lg text-[14px] font-bold hover:bg-surface-container-low transition-colors active:scale-95">
                Our Methodology
              </button>
            </div>
          </div>
          <div className="lg:col-span-5 relative h-[500px] w-full hidden lg:block animate-fade-in">
            {/* Glassmorphic mockup representation */}
            <div className="absolute top-10 right-0 w-[400px] h-[300px] bg-white/70 backdrop-blur-xl border border-white/50 rounded-xl shadow-[0_20px_40px_rgba(15,23,42,0.1)] p-6 z-10 animate-float">
              <div className="h-4 w-1/3 bg-surface-container-high rounded mb-6"></div>
              <div className="space-y-3">
                <div className="h-2 w-full bg-surface-container rounded"></div>
                <div className="h-2 w-5/6 bg-surface-container rounded"></div>
                <div className="h-2 w-4/6 bg-surface-container rounded"></div>
              </div>
              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="h-24 bg-secondary/10 rounded-lg"></div>
                <div className="h-24 bg-secondary/10 rounded-lg"></div>
              </div>
            </div>
            <div className="absolute bottom-10 left-10 w-[300px] h-[350px] bg-white border border-outline-variant/30 rounded-xl shadow-[0_12px_30px_rgba(15,23,42,0.05)] p-6 overflow-hidden">
              <div className="h-32 bg-secondary/5 rounded-lg mb-4"></div>
              <div className="h-3 w-1/2 bg-surface-variant rounded mb-2"></div>
              <div className="h-2 w-1/3 bg-surface-variant rounded"></div>
              <div className="mt-6 space-y-2">
                <div className="h-1.5 w-full bg-surface-container-low rounded"></div>
                <div className="h-1.5 w-full bg-surface-container-low rounded"></div>
                <div className="h-1.5 w-2/3 bg-surface-container-low rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Bento Grid */}
      <section className="py-24 px-8 bg-surface border-y border-outline-variant/20">
        <div className="max-w-[1220px] mx-auto">
          <div className="mb-16 animate-slide-up">
            <h2 className="text-[48px] font-bold text-on-background mb-4 leading-[1.2] tracking-[-0.02em]">Our Services</h2>
            <p className="text-[18px] text-on-surface-variant max-w-3xl">Delivering precision-engineered solutions across the digital spectrum.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 auto-rows-[300px]">
            {/* Enterprise Web Apps */}
            <div className="md:col-span-8 bg-white border border-outline-variant/30 rounded-xl p-8 relative overflow-hidden group shadow-modern hover:shadow-premium transition-all duration-300">
              <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                <span className="material-symbols-outlined text-[120px] text-secondary">computer</span>
              </div>
              <div className="h-full flex flex-col justify-between relative z-10">
                <div>
                  <span className="inline-block p-3 bg-secondary/5 text-secondary rounded-lg mb-6">
                    <span className="material-symbols-outlined">web</span>
                  </span>
                  <h3 className="text-[24px] font-semibold text-on-background mb-3">Web Application</h3>
                  <p className="text-[16px] text-on-surface-variant max-w-md leading-[1.6]">
                    We build modern, fast, and responsive websites using Angular, React, PHP, and Laravel. Whether it's a corporate site, portfolio, or custom web application, we ensure high performance.
                  </p>
                </div>
                <button className="text-secondary font-bold text-[14px] flex items-center gap-2 w-fit hover:gap-3 transition-all">
                  View Case Studies <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                </button>
              </div>
            </div>

            {/* Custom CMS */}
            <div className="md:col-span-4 bg-white border border-outline-variant/30 rounded-xl p-8 relative overflow-hidden shadow-modern">
              <div className="absolute inset-0 bg-gradient-to-br from-transparent to-surface-container-low pointer-events-none opacity-50"></div>
              <div className="h-full flex flex-col justify-between relative z-10">
                <div>
                  <span className="inline-block p-3 bg-surface-container-high text-on-surface rounded-lg mb-6">
                    <span className="material-symbols-outlined">dashboard</span>
                  </span>
                  <h3 className="text-[24px] font-semibold text-on-background mb-3">Software Development</h3>
                  <p className="text-[14px] text-on-surface-variant leading-[1.6]">
                    We provide custom content management systems (CMS) using WordPress, Laravel, and other frameworks, allowing businesses to manage content easily.
                  </p>
                </div>
              </div>
            </div>

            {/* Customized Website */}
            <div className="md:col-span-5 bg-white border border-outline-variant/30 rounded-xl p-8 relative shadow-modern">
              <div className="h-full flex flex-col justify-between relative z-10">
                <div>
                  <span className="inline-block p-3 bg-surface-container-high text-on-surface rounded-lg mb-6">
                    <span className="material-symbols-outlined">design_services</span>
                  </span>
                  <h3 className="text-[24px] font-semibold text-on-background mb-3">Customized Website</h3>
                  <p className="text-[14px] text-on-surface-variant leading-[1.6]">
                    We provide creative website design services for small business, online entrepreneurship ventures. We design websites that stand out among others.
                  </p>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="md:col-span-7 bg-primary-container text-white rounded-xl p-8 relative overflow-hidden shadow-premium">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop')] opacity-10 bg-cover bg-center mix-blend-luminosity"></div>
              <div className="h-full flex flex-col justify-between relative z-10">
                <h3 className="text-[24px] font-semibold text-white mb-6">Performance is a Feature</h3>
                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <div className="text-[48px] font-bold text-secondary-fixed mb-2 leading-none">99.9%</div>
                    <div className="text-[14px] font-semibold text-secondary-fixed/70 uppercase tracking-wider">Uptime SLA</div>
                  </div>
                  <div>
                    <div className="text-[48px] font-bold text-secondary-fixed mb-2 leading-none">&lt;0.5s</div>
                    <div className="text-[14px] font-semibold text-secondary-fixed/70 uppercase tracking-wider">P99 Latency</div>
                  </div>
                  <div>
                    <div className="text-[48px] font-bold text-secondary-fixed mb-2 leading-none">100</div>
                    <div className="text-[14px] font-semibold text-secondary-fixed/70 uppercase tracking-wider">Lighthouse Score</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Products */}
      <section className="py-24 px-8 bg-surface-container-low">
        <div className="max-w-[1220px] mx-auto">
          <div className="mb-16 animate-slide-up">
            <h2 className="text-[48px] font-bold text-on-background mb-4 leading-[1.2] tracking-[-0.02em]">Our Products</h2>
            <p className="text-[18px] text-on-surface-variant max-w-3xl">Explore our portfolio of premium web solutions and enterprise-grade products.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Nexus ERP Dashboard",
                desc: "A comprehensive enterprise resource planning platform featuring real-time analytics and inventory management.",
                type: "analytics"
              },
              {
                title: "SwiftCloud CRM",
                desc: "Tailored customer relationship management system with automated lead scoring and seamless integration.",
                type: "crm"
              },
              {
                title: "Lumina E-Commerce",
                desc: "High-performance digital storefront optimized for mobile-first shopping experiences and multi-vendor scalability.",
                type: "shop"
              }
            ].map((product, i) => (
              <div key={i} className="bg-white border border-outline-variant/30 rounded-xl overflow-hidden shadow-modern group hover:shadow-premium transition-all duration-300 flex flex-col">
                <div className="aspect-video bg-surface-container-low overflow-hidden relative p-4 pb-0 flex flex-col">
                  <div className="bg-white rounded-t-lg shadow-sm flex-grow flex flex-col overflow-hidden border border-outline-variant/20 border-b-0 relative z-10">
                    {/* Browser Chrome */}
                    <div className="h-6 bg-surface-container-low border-b border-outline-variant/10 flex items-center px-2 gap-1.5 shrink-0">
                      <div className="w-1.5 h-1.5 rounded-full bg-outline/20"></div>
                      <div className="w-1.5 h-1.5 rounded-full bg-outline/20"></div>
                      <div className="w-1.5 h-1.5 rounded-full bg-outline/20"></div>
                    </div>
                    {/* Browser Content Preview */}
                    <div className="flex-grow p-3 flex gap-3">
                      <div className="w-1/4 space-y-2">
                        <div className="h-2 w-full bg-surface-container rounded-sm"></div>
                        <div className="h-2 w-5/6 bg-surface-container rounded-sm"></div>
                        <div className="h-2 w-4/6 bg-surface-container rounded-sm"></div>
                      </div>
                      <div className="flex-grow space-y-3">
                        <div className="h-8 w-full bg-secondary/5 rounded-sm"></div>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="h-12 bg-surface-container-low rounded-sm"></div>
                          <div className="h-12 bg-surface-container-low rounded-sm"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-8 flex flex-col flex-grow">
                  <h3 className="text-[20px] font-semibold text-on-background mb-3">{product.title}</h3>
                  <p className="text-[14px] text-on-surface-variant mb-6 flex-grow leading-[1.6]">
                    {product.desc}
                  </p>
                  <button className="text-secondary font-bold text-[14px] flex items-center gap-2 w-fit hover:gap-3 transition-all">
                    View Details <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default WebsitePage;
